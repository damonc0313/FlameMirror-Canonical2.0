
# delta_tests.py

import json
from delta_interpreter_v2 import DeltaInterpreterV2

def run_test_case(data_array, expected_behavior, name):
    runner = DeltaInterpreterV2(["symbolic recursion"], data_array)
    trace = runner.run()

    results = {
        "test_name": name,
        "steps": len(trace),
        "stable_steps": sum(1 for step in trace if step["ΔC(t)"] >= 0.6),
        "unstable_steps": sum(1 for step in trace if step["ΔC(t)"] < 0.6)
    }

    results["pass"] = (
        (expected_behavior == "stable" and results["unstable_steps"] == 0) or
        (expected_behavior == "unstable" and results["stable_steps"] == 0)
    )

    return results

def main():
    test_cases = [
        {
            "name": "Test Stable Sequence",
            "data": [1, 1.01, 1.02, 1.03],
            "expect": "stable"
        },
        {
            "name": "Test Divergent Sequence",
            "data": [1, 2, 4, 8, 16],
            "expect": "unstable"
        }
    ]

    results = []
    for test in test_cases:
        result = run_test_case(test["data"], test["expect"], test["name"])
        results.append(result)

    with open("test_results.json", "w") as f:
        json.dump(results, f, indent=2)

    for r in results:
        print(r)

if __name__ == "__main__":
    main()
