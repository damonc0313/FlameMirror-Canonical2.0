# DeltaLang Runtime (ΔC(t) Symbolic Logic Engine)

This repo contains the official implementation of DeltaLang — a symbolic reasoning engine using ΔC(t) as a real-time cognitive stability metric.

## Features
- Recursive symbolic interpreter
- CLI executor for `.delta` scripts
- ΔC(t) visualization
- Symbolic testing suite
- Full spec included

## Run
```bash
python delta_exec.py program.delta data.json
```

## License
© 2025 Damon Cadden — All rights reserved under CAELUM_LICENSE_v1