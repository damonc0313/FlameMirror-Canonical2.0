
import numpy as np

class DeltaScriptRunner:
    def __init__(self, script_text, array):
        self.script = script_text.strip().splitlines()
        self.array = array
        self.context = {"max": array[0]}
        self.trace = []
        self.p = 2
        self.epsilon = 1e-6
        self.theta = 0.6

    def delta_c(self, xt, xt_1):
        numerator = np.linalg.norm(xt - xt_1, ord=self.p)
        denominator = np.linalg.norm(xt_1, ord=self.p) + self.epsilon
        return 1 - (numerator / denominator)

    def run(self):
        prev_vec = np.array([self.context["max"]])
        self.trace.append({
            "step": 0,
            "value": self.context["max"],
            "Δ": 0,
            "ΔC(t)": 1.0,
            "action": "init max"
        })

        for i in range(1, len(self.array)):
            curr_val = self.array[i]
            Δ = curr_val - self.context["max"]
            ΔC_val = self.delta_c(np.array([curr_val]), prev_vec)

            if Δ > 0:
                self.context["max"] = curr_val
                action = "Δ+ (update max)"
            else:
                action = "Δ= or Δ- (no update)"

            self.trace.append({
                "step": i,
                "value": self.context["max"],
                "Δ": Δ,
                "ΔC(t)": ΔC_val,
                "action": action
            })

            prev_vec = np.array([curr_val])

        return self.context["max"], self.trace
