
# delta_plot.py

import json
import matplotlib.pyplot as plt

def plot_trace(trace_file):
    with open(trace_file, 'r') as f:
        trace = json.load(f)

    steps = [step["step"] for step in trace]
    delta_ct = [step["ΔC(t)"] for step in trace]

    plt.figure(figsize=(10, 5))
    plt.plot(steps, delta_ct, marker='o', label='ΔC(t)')
    plt.axhline(y=0.6, color='r', linestyle='--', label='Stability Threshold θ = 0.6')
    plt.title("ΔC(t) Stability Over Time")
    plt.xlabel("Step")
    plt.ylabel("ΔC(t)")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("delta_ct_trace_plot.png")
    plt.show()

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python delta_plot.py trace.json")
        sys.exit(1)

    plot_trace(sys.argv[1])
