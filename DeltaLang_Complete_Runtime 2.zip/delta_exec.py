
# delta_exec.py

import sys
import json
from delta_interpreter_v2 import DeltaInterpreterV2

def load_script(file_path):
    with open(file_path, 'r') as f:
        return f.read().strip().splitlines()

def load_data(data_path):
    with open(data_path, 'r') as f:
        return json.load(f)

def main(script_path, data_path):
    script_lines = load_script(script_path)
    data_array = load_data(data_path)

    runner = DeltaInterpreterV2(script_lines, data_array)
    trace = runner.run()

    for step in trace:
        print(step)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python delta_exec.py program.delta data.json")
        sys.exit(1)

    script_file = sys.argv[1]
    data_file = sys.argv[2]
    main(script_file, data_file)
